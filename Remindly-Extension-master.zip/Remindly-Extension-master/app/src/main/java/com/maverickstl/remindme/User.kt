package com.maverickstl.remindme

/**
 * Created by robot on 5/14/18.
 */
class User{
    var email : String? = null
    var password : String? = null
    override fun toString(): String {
        return "User(email=$email, password=$password)"
    }


}